G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.0*
G04 #@! TF.CreationDate,2026-04-17T17:39:04+02:00*
G04 #@! TF.ProjectId,PCB_v2,5043425f-7632-42e6-9b69-6361645f7063,1.0*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Copper,L5,Inr*
G04 #@! TF.FilePolarity,Positive*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.0) date 2026-04-17 17:39:04*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
G04 #@! TA.AperFunction,ComponentPad*
%ADD10O,1.000000X2.100000*%
G04 #@! TD*
G04 #@! TA.AperFunction,ComponentPad*
%ADD11O,1.000000X1.800000*%
G04 #@! TD*
G04 #@! TA.AperFunction,ComponentPad*
%ADD12RoundRect,0.250000X-0.600000X-0.725000X0.600000X-0.725000X0.600000X0.725000X-0.600000X0.725000X0*%
G04 #@! TD*
G04 #@! TA.AperFunction,HeatsinkPad*
%ADD13C,0.600000*%
G04 #@! TD*
G04 APERTURE END LIST*
D10*
G04 #@! TO.N,N/C*
G04 #@! TO.C,J2*
X-46655000Y102760000D03*
D11*
X-46655000Y98580000D03*
D10*
X-38015000Y102760000D03*
D11*
X-38015000Y98580000D03*
G04 #@! TD*
D12*
G04 #@! TO.N,/Project Architecture/MCU/CT_4*
G04 #@! TO.C,J6*
X-107175000Y6175000D03*
G04 #@! TD*
G04 #@! TO.N,/Project Architecture/MCU/CT_6*
G04 #@! TO.C,J8*
X-93275000Y6175000D03*
G04 #@! TD*
G04 #@! TO.N,/Project Architecture/MCU/CT_1*
G04 #@! TO.C,J3*
X-128025000Y6175000D03*
G04 #@! TD*
G04 #@! TO.N,/Project Architecture/MCU/CT_5*
G04 #@! TO.C,J7*
X-100225000Y6175000D03*
G04 #@! TD*
D13*
G04 #@! TO.N,GND*
G04 #@! TO.C,U10*
X-109875000Y21765000D03*
X-109875000Y20365000D03*
X-109175000Y22465000D03*
X-109175000Y21065000D03*
X-109175000Y19665000D03*
X-108475000Y21765000D03*
X-108475000Y20365000D03*
X-107775000Y22465000D03*
X-107775000Y21065000D03*
X-107775000Y19665000D03*
X-107075000Y21765000D03*
X-107075000Y20365000D03*
G04 #@! TD*
D12*
G04 #@! TO.N,/Project Architecture/MCU/CT_2*
G04 #@! TO.C,J4*
X-121075000Y6175000D03*
G04 #@! TD*
G04 #@! TO.N,/Project Architecture/MCU/CT_3*
G04 #@! TO.C,J5*
X-114125000Y6175000D03*
G04 #@! TD*
M02*
